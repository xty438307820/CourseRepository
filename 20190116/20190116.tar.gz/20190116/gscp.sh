scp -r test@192.168.2.100:/wangdao/C_C++方向/短期班/Linux/`date +%Y%m%d`/code/* .

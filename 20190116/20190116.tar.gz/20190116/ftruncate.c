#include "func.h"

int main()
{
	int fd=open("file",O_WRONLY);
	ftruncate(fd,1275076116);
	close(fd);
}
